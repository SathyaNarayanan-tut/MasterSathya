// TODO: Write the declaration of swap function here


