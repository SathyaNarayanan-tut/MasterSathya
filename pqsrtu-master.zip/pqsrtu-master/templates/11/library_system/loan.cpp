#include "loan.hh"

Loan::Loan(){

}
