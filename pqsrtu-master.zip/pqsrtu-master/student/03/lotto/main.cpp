#include <iostream>
#include <math.h>

using namespace std;

unsigned long f ( unsigned long n)
{
    if(n>=1)
        return (unsigned long)n*f(n-1);
    else
        return 1;
}

int main()
{
    int n,b;
    unsigned long g,l;
    cout << "Enter the total number of lottery balls: ";
    cin>>n;
    cout << "Enter the number of drawn balls: ";
    cin>>b;
    if (n<0)
    {
        cout<<"The number of balls must be a positive number. \n";
    }
    else if(n<b)
    {
        cout<<"The maximum number of drawn balls is the total amount of balls.";
    }
    else
    {
        g=f(n)/(f(n-b));
        l=g/f(b);
        cout<< "The probability of guessing all "<<b<<" balls correctly is 1/"<<l;
    }

    return 0;
}
