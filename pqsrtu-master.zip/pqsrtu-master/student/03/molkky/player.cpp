#include "player.hh"
using namespace std;
Player::Player(string name):
    name_(name, points_ = 0)
{
}
string Player::get_name() const
{
 return name_;
}
void Player::add_points(int pts)
{
    points_ += pts;
    if(points_ > 50) {
        points_ = 25;
    }
}
bool Player::has_won()
{
    if(points_ == 50) {
        return true;
    }
    return false;
 }
int Player::get_points()
{
return points_;
}
