#include <iostream>
#include <string.h>
using namespace std;
int main()
{
    int n,i;
    cout << "How many numbers would you like to have? ";
    cin >> n;
    for (i=1;i<=n;i++)
    {

        if((i%3==0)&&(i%7==0))
        {
            cout <<"zip boing \n";
        }
        else if(i%3==0)
        {
         cout <<"zip \n";
        }
        else if(i%7==0)
        {
            cout <<"boing \n";
        }
        else
            cout<<i<<"\n";

    }

    return 0;
}
