#include <iostream>
#include <string>
#include <vector>
using namespace std;

// TODO: Implement split function here
// Do not change main function
std::vector < std::string > split (std::string line, char seperator, bool no_empty = false)
{
  std::string::size_type pos = 0;
  std::string token;
  std::vector <std::string> vstring;
  while((pos = line.find(seperator)) != std::string::npos)
  {
      token = line.substr (0, pos);
      line.erase (0, pos+1);
      if(no_empty)
      {
          if(token != " " && token !="")
          {
              vstring.push_back (token);
          }
      }
      else {
          vstring.push_back(token);
      }
  }
  vstring.push_back (line);
  return vstring;
}

int main()
{
    std::string line = "";
    std::cout << "Enter a string: ";
    getline(std::cin, line);
    std::cout << "Enter the separator character: ";
    char separator = getchar();

    std::vector< std::string > parts  = split(line, separator);
    std::cout << "Splitted string including empty parts: " << std::endl;
    for( auto part : parts ) {
        std::cout << part << std::endl;
    }

    std::vector< std::string > parts_no_empty  = split(line, separator, true);
    std::cout << "Splitted string ignoring empty parts: " << std::endl;
    for( auto part : parts_no_empty ) {
        std::cout << part << std::endl;
    }
}
