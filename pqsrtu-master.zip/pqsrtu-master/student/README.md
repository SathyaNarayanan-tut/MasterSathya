Tähän hakemistoon kopioit koodipohjat templates-hakemistosta tai luot uudet ohjelmointiprojektit.

--------------------

In this directory, you will copy template codes from the directory called templates, or create new programming projects.