#include <iostream>

// Write here a function counting the mean value

int main()
{
    std::cout << "From how many integer numbers you want to count the mean value? ";
}
