#include <iostream>
#include <math.h>
using namespace std;

int main()
{
    int n,c;
    cout << " Enter a number: ";
    cin>>n;
    c=(n*n*n);
    long n1 = (long) c;
    long c1 = (n1*n1*n1);
    if(!(c1 == c))
    cout<<"Error! The cube of "<<n<<" is not "<<c;
    else
        cout<<"The cube of "<<n<< " is "<<c;
    return 0;
}
