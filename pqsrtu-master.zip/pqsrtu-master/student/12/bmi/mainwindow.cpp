#include "mainwindow.hh"
#include "ui_mainwindow.h"
#include <math.h>
#include <iostream>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_weightLineEdit_editingFinished()
{
    weight_ =ui->weightLineEdit->text().toInt();
}

void MainWindow::on_heightLineEdit_editingFinished()
{
    height_= ui->heightLineEdit->text().toInt();
}

void MainWindow::on_countButton_clicked()
{
//    float Bmi;
    float weight=weight_;
    float height=height_;
    height=height/100;
    float Bmi=weight/pow(height,2);
    ui->resultLabel->setText(QString::number(Bmi));
    if(Bmi<18.5)
    {
        ui->infoTextBrowser->setText("You are underweight.");
    }
    else if(Bmi>25)
    {
        ui->infoTextBrowser->setText("You are overweight.");
    }
    else
    {
        ui->infoTextBrowser->setText("Your weight is normal.");
    }
}
