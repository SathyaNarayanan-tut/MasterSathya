#ifndef PLAYER_H
#define PLAYER_H


class player
{
public:
    player();
};

#endif // PLAYER_H