#include "cards.hh"

using namespace std;
Cards::Cards(): top_(nullptr){

}

void Cards::add(int id)
{
   Card_data* new_card =new Card_data;
   new_card->data=id;
   new_card->next=top_;
   top_ =new_card;
}

void Cards::print_from_top_to_bottom(std::ostream& s)
{
    Card_data* currentptr = top_;
    int line=1;
    while(currentptr!=nullptr)
    {
        s <<line<<": "<<currentptr->data<<std::endl;
        currentptr=currentptr->next;
        ++line;
    }
}

bool Cards::remove(int &id)
{
    if(top_==nullptr)
    {
        return false;
    }
    Card_data* remove_ptr =top_;
    id=remove_ptr->data;
    top_=remove_ptr->next;
    delete  remove_ptr;

    return true;
}

bool Cards::bottom_to_top()
{
    if(top_==nullptr)
    {
        return false;
    }else if (top_->next==nullptr)
    {
        return true;
    }
    Card_data* helperptr=top_;
    while(helperptr->next->next!=nullptr)
    {
        helperptr=helperptr->next;
    }
    Card_data* last_ptr=helperptr->next;
    last_ptr->next=top_;
    top_=last_ptr;
    helperptr->next=nullptr;

    return true;
}

bool Cards::top_to_bottom()
{
    if(top_==nullptr)
    {
        return false;
    }
    else if(top_->next==nullptr)
    {
        return true;
    }
    Card_data* helperptr =top_->next;
    while(helperptr->next!=nullptr)
    {
        helperptr=helperptr->next;
    }
    Card_data* first=top_;
    helperptr->next=first;
    top_=first->next;
    first->next=nullptr;

    return true;
}

void Cards::print_from_bottom_to_top(ostream& s)
{
     recursive_print(top_, s);
}

Cards::~Cards()
{
    while (top_!=nullptr)
    {
        int dummy;
        remove(dummy);
    }
}

int Cards::recursive_print(Cards::Card_data* top, ostream& s){
    if (top==nullptr)
        {
            return EXIT_SUCCESS;
        }
        else
        {
            int num=recursive_print(top->next, s)+1;
            s <<num<<": "<< top->data<<endl;
            return num;
        }
}

