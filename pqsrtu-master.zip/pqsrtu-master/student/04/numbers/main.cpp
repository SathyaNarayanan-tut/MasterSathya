﻿/* Numbers ( or 2048, but that's an invalid name ) : Template code
 *
 * Desc:
 *  This program generates a game of 2048, a tile combining game
 * where the goal is to get from 2's to 2048. The board is SIZE x SIZE,
 * ( original was 4x4 ) and every round the player chooses a direction
 * to which the tiles should fall. If they collide with a wall or a different
 * value, they will move as close as they can get. If they collide with
 * a tile with same value, they will combine and double the value. The
 * tile will continue to move until a wall or other tile comes along, but a
 * single tile can only be combined once per "turn".
 *  Game will end when the goal value asked (orig 2048) is reached or new
 * tile can't be added to the board.
 *
 * Program author ( Fill with your own info )
 * Name: Sri Sathya Narayanan Tutupalli Srikanth
 * Student number: 292990
 * UserID: pqsrtu
 * E-Mail: sri.tutupallisrikanth@tuni.fi
 *
 * Notes about the program and it's implementation:
 * */

#include "numbertile.hh"
#include <iostream>
#include <vector>
#include <random>
#include <string>
#include <ctime>

const int SIZE = 4;
const int NEW_VALUE = 2;
const int PRINT_WIDTH = 5;
const int DEFAULT_GOAL = 2048;

enum Direction { up, down, left, right, QUIT };

// Reads the input and returns an enum describing it.
// Prints a message when wrong commands are entered.
Direction getdirect()
{
    std::string input = "\n";
    std::cout << "Dir> ";
    std::cin >> input;

    if(input.length() > 1)
    {
        // more than one character, ask again for the input
        std::cout << "Error: unknown command." << std::endl;
        return getdirect();
    }

    switch(input.at(0))
    {
        case 'w':
            return Direction::up;
        case 's':
            return Direction::down;
        case 'a':
            return Direction::left;
        case 'd':
            return Direction::right;
        case 'q':
            return Direction::QUIT;
        default:
            // wrong ask again for the input
            std::cout << "Error: unknown command." << std::endl;
            return getdirect();
    }
}

enum RotationType { clockwise, anticlockwise };

// Rotates the board clockwise or anticlockwise to match the basic matrix form required by the function cRow.
void rotateBoard(std::vector<std::vector<NumberTile>> &board, const RotationType &rotation)
{
    switch(rotation)
    {
        case RotationType::clockwise:
        for (size_t y=0; y<SIZE/2; ++y)
        {
          for (size_t x=y; x<SIZE-y-1; ++x)
          {
              // Swapping elements after each iteration in Clockwise direction
                  NumberTile temp=board.at(y).at(x);
                  board.at(y).at(x) = board.at(SIZE-1-x).at(y);
                  board.at(SIZE-1-x).at(y) = board.at(SIZE-1-y).at(SIZE-1-x);
                  board.at(SIZE-1-y).at(SIZE-1-x) = board.at(x).at(SIZE-1-y);
                  board.at(x).at(SIZE-1-y) = temp;
          }
        }
        break;
    case RotationType::anticlockwise:
        for (size_t y=0; y<SIZE/2; ++y)
        {
          for (size_t x=y; x<SIZE-y-1; ++x)
          {
              // Swapping elements after each iteration in Anticlockwise direction
                  NumberTile temp=board.at(y).at(x);
                  board.at(y).at(x) = board.at(x).at(SIZE-y-1);
                  board.at(x).at(SIZE-y-1) = board.at(SIZE-y-1).at(SIZE-x-1);
                  board.at(SIZE-y-1).at(SIZE-x-1) = board.at(SIZE-x-1).at(y);
                  board.at(SIZE-x-1).at(y) = temp;
          }
        }
        break;
    }
}

// Returns true if the row is empty.
bool isEmptyRow(const std::vector<NumberTile> &row)
{
    for (size_t x = 0; x<SIZE; ++x)
    {
        if(row.at(x).getValue() != 0)
            return false;
    }
    return true;
}

// Swapping the two tiles.
void swapValues(NumberTile* a, NumberTile* b)
{
    int temp = b->getValue();
    b->updateValue(a->getValue());
    a->updateValue(temp);
}

// empty the tiles to the left.
void shiftZeros(std::vector<NumberTile> &row)
{
    NumberTile* currentTile = &row.front();
    bool hasToBacktrack = false;
    while(currentTile != &row.back())
    {
        if(currentTile->getValue() != 0)
        {
            NumberTile* nextTile = currentTile+1;
            if(nextTile->getValue() == 0)
            {
                //all valid values to the right and push all zeros to the left of the matrix.
                swapValues(currentTile, nextTile);
                hasToBacktrack = true;
            }
        }
        if(hasToBacktrack)
        {
            currentTile = &row.front();
            hasToBacktrack = false;
        }
        else
        {
            currentTile++;
        }
    }

}

// This logic works for whenever the board is allined right, meaning that this is the logic used after a right command.
void cRow(std::vector<NumberTile> &row)
{
    // clean all zeros in the way
    shiftZeros(row);

    // go from right to left and merge tiles where possible
    NumberTile* currentTile = &row.back();
    while(currentTile != &row.front())
    {
        if(currentTile->getValue() != 0)
        {
            NumberTile* previousTile = currentTile-1;
            if(previousTile->getValue() == currentTile->getValue())
            {
                // merging tile values
                currentTile->updateValue(currentTile->getValue()*2);
                previousTile->updateValue(0);
            }
        }
        currentTile--;
    }

    // clean all zeros again in case there's some left in between actual values after the merge
    shiftZeros(row);
}

// Runs the empty row check and cRow logic for all rows in the board.
void moveTiles(std::vector<std::vector<NumberTile>> &board)
{
    // check from first row
    for (size_t y = 0; y < SIZE; y++)
    {
        // check if there's any number != 0
        if(isEmptyRow(board.at(y)))
            continue;
        cRow(board.at(y));
    }
}

// Decide how to rotate the board based on the input and call the other functions to move the tiles.
void handleInput(std::vector<std::vector<NumberTile>> &board, const Direction &direction)
{
    switch(direction)
    {
        case Direction::up:
            rotateBoard(board, RotationType::clockwise);
            moveTiles(board);
            // restore board rotation
            rotateBoard(board, RotationType::anticlockwise);
            break;
        case Direction::down:
            rotateBoard(board, RotationType::anticlockwise);
            moveTiles(board);
            // restore board rotation
            rotateBoard(board, RotationType::clockwise);
            break;
        case Direction::left:
            rotateBoard(board, RotationType::clockwise);
            rotateBoard(board, RotationType::clockwise);
            moveTiles(board);
            // restore board rotation
            rotateBoard(board, RotationType::anticlockwise);
            rotateBoard(board, RotationType::anticlockwise);
            break;
        case Direction::right:
            // no rotation this is the default position for the cRow logic
            moveTiles(board);
            break;
        case Direction::QUIT:
            break;
    }
    return;
}

enum GameState { RUNNING, WON, LOST };

// Returns WON if the goal is reached, LOST if the board is full, RUNNING if the game can continue.
GameState checkGameState(const std::vector<std::vector<NumberTile>> &board, const int &goal)
{
    bool hasEmptyTile = false;
    for(size_t y=0; y<SIZE; ++y)
    {
        for(size_t x=0; x<SIZE; ++x)
        {
            if(board.at(y).at(x).getValue() == goal)
                return GameState::WON;
            if(!hasEmptyTile && board.at(y).at(x).getValue() == 0)
                hasEmptyTile = true;
        }
    }

    if(hasEmptyTile)
        return GameState::RUNNING;

    return GameState::LOST;
}

// Adds a single new value to board using rEng and distr for random positioning.
void newValue(std::vector<std::vector<NumberTile>> &board,
              std::default_random_engine &rEng,
              std::uniform_int_distribution<int> &distr){
    // Tries to assign NEW_VAl to randomly selected tile. Continues trying until
    // newVal() returns true.
    while(!board.at(distr(rEng)).at(distr(rEng)).setValue(NEW_VALUE));
}

// Initializes the board to size SIZE x SIZE and adds SIZE tiles with NEW_VALUE
// to it through new_value() func after initializing the random engine with
// a seed value.
void initBoard(std::vector<std::vector<NumberTile>> &board,
               std::default_random_engine &rEng,
               std::uniform_int_distribution<int> &distr){

    // Initialize the board with SIZE x SIZE empty numbertiles.
    for ( size_t y = 0; y < SIZE; y++ ){
        board.push_back({});
        for ( size_t x = 0; x < SIZE; x++ ){
            // If you don't want to use pairs, replace "std::make_pair(y, x)"
            // with "y, x".
            board.at(y).push_back(NumberTile(0, std::make_pair(y, x), &board));
        }

    }

    // Ask user for the seed value and initialize rEng.
    std::cout << "Give a seed value or an empty line: ";
    std::string seed = "";
    getline(std::cin, seed);

    if(seed == "") {
        // If the user did not give a seed value, use computer time as the seed
        // value.
        rEng.seed(time(NULL));
    } else {
        // If the user gave a seed value, use it.
        rEng.seed(stoi(seed));
    }

    // Add some tiles to the board.
    for ( int i = 0 ; i < SIZE ; ++i ){
        newValue(board, rEng, distr);
    }
}

// Allows the user to set a custom goal.
int initGoal()
{
    std::cout << "Give a goal value or an empty line: ";
    std::string goal = "";
    getline(std::cin, goal);
    bool isBadInput = false;
    if(goal != "")
    {
        // check for correct parsable input
        for(char c : goal)
        {
            if(!isdigit(c))
                isBadInput = true;
        }
        if(!isBadInput)
        {
            return stoi(goal);
        }
    }
    return DEFAULT_GOAL;
}

// Prints the board.
void print(const std::vector<std::vector<NumberTile>> &board){
    // The y isn't actually the y coordinate or some int, but an iterator that
    // is like a vector of NumberTiles.
    for ( auto y : board ){
        // Prints a row of dashes.
        std::cout << std::string(PRINT_WIDTH * SIZE + 1, '-') << std::endl;
        // And then print all cells in the desired width.
        for ( auto x : y ){
            x.print(PRINT_WIDTH);
        }
        // And a line after each row.
        std::cout << "|" << std::endl;
    }
    // Print a last row of dashes so that the board looks complete.
    std::cout << std::string(PRINT_WIDTH * SIZE + 1, '-') << std::endl;
}

int main()
{
    // Declare the board and randomengine.
    std::vector<std::vector<NumberTile>> board;
    std::default_random_engine randomEng;
    // And initialize the distr to give numbers from the correct
    std::uniform_int_distribution<int> distr(0, SIZE - 1);

    initBoard(board, randomEng, distr);
    int goal = initGoal();

    GameState state = GameState::RUNNING;

    while(true)
    {
        print(board);

        Direction input = getdirect();
        if(input == Direction::QUIT)
            return EXIT_SUCCESS;
        else
        {
            handleInput(board, input);
            state = checkGameState(board, goal);
            if(state == GameState::WON)
            {
                print(board);
                std::cout << "You reached the goal value of " << goal << "!" << std::endl;
                return EXIT_SUCCESS;
            }
            else if(state == GameState::LOST)
            {
                std::cout << "Can't add new tile, you lost!" << std::endl;
                return EXIT_SUCCESS;
            }
            newValue(board, randomEng, distr);
        }
    }
}

