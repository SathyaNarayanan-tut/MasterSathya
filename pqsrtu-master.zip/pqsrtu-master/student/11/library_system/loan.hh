/* Module: Loan
 * ------------
 * This class and its bahaviour should be defined by the student.
 *
 * TIE-0220x S2019
 * */
#ifndef LOAN_HH
#define LOAN_HH
#include "person.hh"
#include "book.hh"
#include "date.hh"
#include <string>
const int DEFAULT_RENEWAL_AMOUNT = 6;

class Loan
{
public:
    Loan(Book* book,Person* borrower,Date* today);
    ~Loan();

    //descriptive getters.
    Book* get_book();
    Person* get_borrower();
    Date* get_due_date();
    bool get_is_late();

    //prints the information of loaned book.
    void print_information();
    //prints information of loaned book by borrower.
    void print_loan_taken();
    //renew duedate
    //renewal times over then renewal fails.
    bool renew_loan();
    //due date already passed or not.
    void check_due_date(Date* today);

private:
    Book* book_;
    Person* borrower_;
    Date* due_date_;
    bool is_late_;
    unsigned int renewal_;
};

#endif // LOAN_HH
