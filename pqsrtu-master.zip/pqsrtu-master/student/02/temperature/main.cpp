#include <iostream>

using namespace std;

int main()
{
    float f,c,t;
    cout << "Enter a temperature: ";
    cin >> t ;
    f = (t * 1.8) + 32;
    cout << t << " degrees Celsius is "<< f << " degrees Fahrenheit "<<"\n";
    c = (t - 32)/ 1.8;
    cout << t << " degrees Fahrenheit is "<< c << " degrees Celsius ";

    return 0;
}
