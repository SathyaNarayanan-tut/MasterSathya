#include <iostream>
using namespace std;
int main()
{
    int n,i;
    float m[100],sum=0,mean;
    cout << "From how many integer numbers you want to count the mean value? ";
    cin >>n;
    if(n==0)
    {
        cout<<"Cannot count mean value from 0 numbers";
    }

    else
    {    for(i=0;i<n;i++)
    {
        cout<<" Input "<<i+1<<". number: ";
        cin>>m[i];
        sum+=m[i];
    }
    mean= sum/n;
    cout<<"Mean value of the given numbers is "<<mean;
    }

    return 0;
}

