#include "mainwindow.hh"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    timer=new QTimer;
    connect(timer,&QTimer::timeout,this,&MainWindow::timecount);
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::timecount()
{
    ++seconds_;
    minutes_=seconds_/60;
    int seconds = seconds_%60;
    ui->lcdNumberMin->display(minutes_);
    ui->lcdNumberSec->display(seconds);
}

void MainWindow::on_startButton_clicked()
{
    timer->start(1000);
}

void MainWindow::on_stopButton_clicked()
{
    timer->stop();
}

void MainWindow::on_resetButton_clicked()
{
    minutes_=0;
    seconds_=0;
    ui->lcdNumberMin->display(minutes_);
    ui->lcdNumberSec->display(seconds_);
}
