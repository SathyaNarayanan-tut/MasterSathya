#include <iostream>
#include <string.h>
#include <ctype.h>
using namespace std;

int main()
{
    int i;
    char str1[100];
   {
    int il=0;
    char str[100];

    cout << "Enter the encryption key: ";
    cin.getline(str,100);
    if (strlen(str)!=26)
    {
        cout<<"Error! The encryption key must contain 26 characters.";
        return EXIT_FAILURE;
    }
    else if ((str[il]=='A')||(str[il]=='B')||(str[il]=='c')||(str[il]=='d')||(str[il]=='E')||(str[il]=='F')||(str[il]=='g')||(str[il]=='H')||(str[il]=='I')||(str[il]=='J')||(str[il]=='k')||(str[il]=='L')||(str[il]=='M')||(str[il]=='N')||(str[il]=='O')||(str[il]=='P')||(str[il]=='Q')||(str[il]=='R')||(str[il]=='S')||(str[il]=='T')||(str[il]=='U')||(str[il]=='V')||(str[il]=='W')||(str[il]=='X')||(str[il]=='Y')||(str[il]=='Z'))
    {    

        cout<<"Error! The encryption key must contain only lower case letters.";
        return EXIT_FAILURE;
    }
    else if(str[il]<='a'||str[il]>='z')
    {
        cout<<"Error! The encryption key must contain all alphabets a-z.";
        return EXIT_FAILURE;
    }
    else
    cout<<"Enter the text to be encrypted: ";
    cin>>str1;
      for(i=0;(i<100&&str1[i]!='\0');i++)
        str1[i]=str1[i]+2;
    cout<<"Encrypted text: "<<str1;
    }
    return 0;
}
