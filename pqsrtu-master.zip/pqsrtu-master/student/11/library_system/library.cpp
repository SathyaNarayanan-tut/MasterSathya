#include "library.hh"
#include <iostream>
#include <map>
using namespace std;
// Let's use the date when the project was published as the first date.
Library::Library():
    today_(new Date(13, 11, 2019)),
    books_({}),
    authors_({}),
    accounts_({})
{

}
Library::~Library()
{
    // Free all memory reserved with the keyword new.
    delete today_; today_ = nullptr;
    for ( std::pair<std::string, Book*> book : books_ ){
        delete book.second;
        book.second = nullptr;
    }
    for ( std::pair<std::string, Person*> author : authors_ ){
        delete author.second;
        author.second = nullptr;
    }
    for ( std::pair<std::string, Person*> account : accounts_ ){
        delete account.second;
        account.second = nullptr;
    }
    for(pair<string, Loan*> loan : lo_)
    {
        delete loan.second;
        loan.second=nullptr;
    }

}

void Library::all_books()
{
    for ( std::pair<std::string, Book*> book : books_ ){
        std::cout << book.first << std::endl;
    }
}

void Library::all_books_with_info()
{
    std::cout << SEPARATOR_LINE << std::endl;
    for ( std::pair<std::string, Book*> book : books_ ){
        book.second->print_info();
        std::cout << SEPARATOR_LINE << std::endl;
    }
}

void Library::all_borrowers()
{
    for ( std::pair<std::string, Person*> borrower : accounts_ ){
        std::cout << borrower.first << std::endl;
    }
}

void Library::all_borrowers_with_info()
{
    std::cout << SEPARATOR_LINE << std::endl;
    for ( std::pair<std::string, Person*> borrower : accounts_ ){
        borrower.second->print_info();
        std::cout << SEPARATOR_LINE << std::endl;
    }
}

bool Library::add_book(const std::string &title, const std::vector<std::string> authors, const std::string &description, const std::set<std::string> genres)
{
    if ( authors.empty() ){
        std::cout << MISSING_AUTHOR_ERROR << std::endl;
        return false;
    }
    std::vector<Person*> author_ptrs;
    for ( std::string author : authors ){
        Person* n_person;
        if ( authors_.find(author) == authors_.end() ){
            n_person = new Person(author, "", "");
            authors_.insert({author, n_person});
        } else {
            n_person = authors_.at(author);
        }
        author_ptrs.push_back(n_person);
    }
    Book* n_book = new Book(title, author_ptrs, description, genres);
    books_.insert({title, n_book});
    return true;
}

void Library::add_borrower(const std::string &name, const std::string &email,
                           const std::string &address)
{
    if ( accounts_.find(name) != accounts_.end()){
        std::cout << DUPLICATE_PERSON_ERROR << std::endl;
        return;
    }

    Person* n_person = new Person(name, email, address);
    accounts_.insert({name, n_person});
}

void Library::set_date(int day, int month, int year)
{
    delete today_;
    today_ = new Date(day, month, year);
    today_->show();
    for(pair<string,Loan*> loan:lo_)
    {
        loan.second ->check_due_date(today_);
    }
}

void Library::advance_date(int days)
{
    today_->advance_by(days);
    today_->show();
    for(pair<string,Loan*>loan : lo_)
    {
        loan.second->check_due_date(today_);
    }
}

void Library::loaned_books()
{
   if(lo_.size()==0)
   {
       return;
   }
   cout<< LOAN_INFO << endl;
   for(pair<string,Loan*> loan : lo_)
   {
       loan.second->print_information();
   }
}

void Library::loans_by(const std::string &borrower)
{
  if(accounts_.find(borrower)==accounts_.end())
  {
      cout<< CANT_FIND_ACCOUNT_ERROR <<endl;
      return;
  }
  for(pair<string,Loan*> loan:lo_)
  {
      if(loan.second->get_borrower()->get_name()==borrower)
      {
          loan.second->print_loan_taken();
      }
  }
}

void Library::loan(const std::string &book_title, const std::string &borrower_id)
{
   map<string,Book*>::iterator b_ = books_.find(book_title);
   if(b_ == books_.end())
   {
       cout<< CANT_FIND_BOOK_ERROR << endl;
       return;
   }
   Book* book = b_->second;
   map<string,Person*>::iterator a_ = accounts_.find(borrower_id);
   if(a_ == accounts_.end())
   {
       cout<< CANT_FIND_ACCOUNT_ERROR << endl;
       return;
   }
   Person* borrower = a_->second;
   if(lo_.find(book_title)!= lo_.end())
   {
       cout<< ALREADY_LOANED_ERROR << endl;
       return;
   }
   unsigned int day = today_->getDay();
   unsigned int month = today_->getMonth();
   unsigned int year = today_->getYear();
   Date* n_date = new Date(day,month,year);
   Loan* n_loan = new Loan(book,borrower,n_date);
   lo_.insert({book_title,n_loan});
}

void Library::renew_loan(const std::string &book_title)
{
  if(books_.find(book_title)==books_.end())
  {
      cout<< CANT_FIND_BOOK_ERROR << endl;
      return;
  }
  map<string,Loan*>::iterator iter = lo_.find(book_title);
  if(iter == lo_.end())
  {
      cout<< LOAN_NOT_FOUND_ERROR << endl;
      return;
  }
  Loan* loan = iter->second;
  if(loan->renew_loan())
  {
      cout<< RENEWAL_SUCCESSFUL <<
             loan->get_due_date()->to_string() <<
             endl;
  }
  else
  {
      cout<< OUT_OF_RENEWALS_ERROR << endl;
  }
}

void Library::return_loan(const std::string &book_title)
{
  if(books_.find(book_title)==books_.end())
  {
      cout<< CANT_FIND_BOOK_ERROR <<endl;
      return;
  }
  map<string,Loan*>::iterator iter =lo_.find(book_title);
  if(iter == lo_.end())
  {
      cout<< LOAN_NOT_FOUND_ERROR << endl;
      return;
  }
  delete iter->second;
  lo_.erase(iter);
  cout<< RETURN_SUCCESSFUL << endl;
}
