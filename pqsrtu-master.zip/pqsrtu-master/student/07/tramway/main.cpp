#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
#include <iomanip>

const char FIELD_SEPARATOR = ';';

// The most magnificent function in this whole program.
// Prints a RASSE
void print_rasse()
{
    std::cout <<
                 "=====//==================//===\n"
                 "  __<<__________________<<__   \n"
                 " | ____ ____ ____ ____ ____ |  \n"
                 " | |  | |  | |  | |  | |  | |  \n"
                 " |_|__|_|__|_|__|_|__|_|__|_|  \n"
                 ".|                  RASSE   |. \n"
                 ":|__________________________|: \n"
                 "___(o)(o)___(o)(o)___(o)(o)____\n"
                 "-------------------------------" << std::endl;
}

std::vector<std::string> split(std::string str, const char &separator, const bool &ignoreInQuotes = true, const bool &ignoreEmpty = false)
{
    std::vector<std::string> splittedStr = {};
    size_t len = str.length();
    size_t occurrencePos = 0;

    do
    {
        occurrencePos = str.find(separator);
        if(occurrencePos != std::string::npos)
        {
            if(ignoreInQuotes)
            {
                size_t prevQuotePos = str.find('\"');
                if(prevQuotePos != std::string::npos && prevQuotePos < occurrencePos)
                {
                    if(std::count(str.begin(),
                                  str.begin() + static_cast<std::string::difference_type>(prevQuotePos),
                                  '\"')
                            % 2 == 0)
                    {
                        // prevQuote is an opening quote
                        size_t nextQuotePos = str.find('\"', occurrencePos + 1);
                        if(nextQuotePos != std::string::npos)
                        {
                            std::string part = str.substr(prevQuotePos + 1, nextQuotePos);
                            splittedStr.push_back(part);
                            occurrencePos = nextQuotePos;
                            str = str.substr(++occurrencePos);
                            continue;
                        }
                    }
                }
            }
            std::string part = str.substr(0, occurrencePos);
            if(!ignoreEmpty || part != "")
            {
                splittedStr.push_back(part);
            }
            str = str.substr(++occurrencePos);
        }
    } while(occurrencePos < len && occurrencePos != std::string::npos);

    // check if there is a last empty part at the end
    if(!ignoreEmpty || (ignoreEmpty && !str.empty()))
        splittedStr.push_back(str);

    return splittedStr;
}

bool parseFile(const std::string &fileName, std::map<std::string, std::vector<std::string>> &data,
               std::set<std::string> &stationsRegistry)
{
    std::ifstream inputFile(fileName);

    if(inputFile)
    {
        std::string input = "";
        while(getline(inputFile, input))
        {
            std::vector<std::string> dataFields = split(input, FIELD_SEPARATOR);

            if(dataFields.size() != 2) // fields in each line should always be two
            {
                std::cout << "Error: Invalid format in file." << std::endl;
                return false;
            }

            std::string line = dataFields.front();
            std::string station = dataFields.back();

            if(line == "" || station == "") // both fields should have a value
            {
                std::cout << "Error: Invalid format in file." << std::endl;
                return false;
            }

            // valid data
            std::map<std::string, std::vector<std::string>>::iterator foundLine = data.find(line);
            if(foundLine == data.end())
            {
                // add new line
                data.insert( { line, {station} } );
                stationsRegistry.insert(station);
            }
            else
            {
                // line exists, check for station
                std::vector<std::string>::iterator foundStation =
                        std::find(foundLine->second.begin(), foundLine->second.end(), station);
                if(foundStation == foundLine->second.end())
                {
                    // add new station
                    foundLine->second.push_back(station);
                    stationsRegistry.insert(station);
                }
                else
                {
                    // station already exists
                    std::cout << "Error: Station/line already exists." << std::endl;
                    return false;
                }
            }
        }
        inputFile.close();
    }
    else
    {
        std::cout << "Error: File could not be read." << std::endl;
        return false;
    }
    return true;
}

std::vector<std::string> getCommandArgs(std::string commandText)
{
    std::vector<std::string> params = split(commandText, ' ');
    for(std::string &param : params)
    {
        // use erase?remove idiom to remove all quotes
        param.erase(std::remove(param.begin(), param.end(), '\"'), param.end());
    }
    // fill any missing params (max 4)
    params.resize(4);
    return params;
}

enum Command
{
    QUIT,
    LINES,
    LINE,
    STATIONS,
    STATION,
    ADD_LINE,
    ADD_STATION,
    REMOVE_STATION,
    UNKNOWN
};

Command handleCommand(std::string command)
{
    if(command == "QUIT")
        return Command::QUIT;
    if(command == "LINES")
        return Command::LINES;
    if(command == "STATIONS")
        return Command::STATIONS;
    if(command == "LINE")
        return Command::LINE;
    if(command == "STATION")
        return Command::STATION;
    if(command == "ADDLINE")
        return Command::ADD_LINE;
    if(command == "ADDSTATION")
        return Command::ADD_STATION;
    if(command == "REMOVE")
        return Command::REMOVE_STATION;
    return Command::UNKNOWN;
}

void printLines(const std::map<std::string, std::vector<std::string>> &data)
{
    std::cout << "All tramlines in alphabetical order:" << std::endl;
    for(const std::map<std::string, std::vector<std::string>>::value_type &line : data)
    {
        std::cout << line.first << std::endl;
    }
}

void printStations(const std::set<std::string> &stationsRegistry)
{
    std::cout << "All stations in alphabetical order:" << std::endl;
    for(const std::string &station : stationsRegistry)
    {
        std::cout << station << std::endl;
    }
}

void printLine(std::map<std::string, std::vector<std::string>> &data, const std::string &line)
{
    if(line.length() != 0)
    {
        std::map<std::string, std::vector<std::string>>::iterator foundLine = data.find(line);
        if(foundLine != data.end())
        {
            std::cout << "Line " << line
                      << " goes through these stations in the order they are listed:" << std::endl;
            std::vector<std::string> station = foundLine->second;
            for(const std::string &station : foundLine->second)
            {
                std::cout << " - " << station << std::endl;
            }
        }
        else
        {
            std::cout << "Error: Line could not be found." << std::endl;
        }
    }
    else
    {
        std::cout << "Error: Invalid input." << std::endl;
    }
}

void printStation(std::map<std::string, std::vector<std::string>> &data, const std::string &station)
{
    if(station.length() != 0)
    {
        std::vector<std::string> linesWithStation = {};
        for(std::map<std::string, std::vector<std::string>>::value_type &line : data)
        {
            std::vector<std::string>::iterator foundStation =
                    std::find(line.second.begin(), line.second.end(), station);
            if(foundStation != line.second.end())
            {
                linesWithStation.push_back(line.first);
            }
        }

        if(linesWithStation.size() == 0)
        {
            std::cout << "Error: Station could not be found." << std::endl;
        }
        else
        {
            std::cout << "Station " << station << " can be found on the following lines:" << std::endl;
            for(const std::string &line : linesWithStation)
            {
                std::cout << " - " << line << std::endl;
            }
        }
    }
    else
    {
        std::cout << "Error: Invalid input." << std::endl;
    }
}

void addLine(std::map<std::string, std::vector<std::string>> &data, const std::string &line)
{
    if(line.length() != 0)
    {
        std::map<std::string, std::vector<std::string>>::iterator foundLine = data.find(line);
        if(foundLine == data.end())
        {
            // line doesn't exist, add it without stations
            data.insert({ line, {}});
            std::cout << "Line was added." << std::endl;
        }
        else
        {
            std::cout << "Error: Station/line already exists." << std::endl;
        }
    }
    else
    {
        std::cout << "Error: Invalid input." << std::endl;
    }
}

void addStation(std::map<std::string, std::vector<std::string>> &data, std::set<std::string> &stationsRegistry, const std::vector<std::string> &params)
{
    std::string line = params.at(0);
    std::string station = params.at(1);
    std::string nextStation = params.at(2);
    if(line.length() != 0 && station.length() != 0)
    {
        std::map<std::string, std::vector<std::string>>::iterator foundLine = data.find(line);
        if(foundLine != data.end())
        {
            // line exists
            std::vector<std::string>::iterator foundStation =
                    std::find(foundLine->second.begin(), foundLine->second.end(), station);
            if(foundStation == foundLine->second.end())
            {
                // station does not exists, check where to add it
                if(nextStation.length() != 0)
                {
                    std::vector<std::string>::iterator foundNextStation =
                            std::find(foundLine->second.begin(), foundLine->second.end(), nextStation);
                    if(foundNextStation != foundLine->second.end())
                    {
                        // next station exists, add station before it
                        foundLine->second.insert(foundNextStation, station);
                    }
                    else
                    {
                        // next station does not exist, add station as last
                        foundLine->second.push_back(station);
                    }
                }
                else
                {
                    // next station not provided, add station as last
                    foundLine->second.push_back(station);
                }
                stationsRegistry.insert(station);
                std::cout << "Station was added." << std::endl;
            }
            else
            {
                std::cout << "Error: Station/line already exists." << std::endl;
            }
        }
        else
        {
            std::cout << "Error: Line could not be found." << std::endl;
        }
    }
    else
    {
        std::cout << "Error: Invalid input." << std::endl;
    }
}

void removeStation(std::map<std::string, std::vector<std::string>> &data, std::set<std::string> &stationsRegistry, const std::string &station)
{
    if(station.length() > 0)
    {
        bool removed = false;
        for(std::map<std::string, std::vector<std::string>>::value_type &line : data)
        {
            std::vector<std::string>::iterator foundStation =
                    std::find(line.second.begin(), line.second.end(), station);
            if(foundStation != line.second.end())
            {
                line.second.erase(foundStation);
                if(!removed)
                    removed = true;
            }
        }
        if(removed)
        {
            stationsRegistry.erase(station);
            std::cout << "Station was removed from all lines." << std::endl;
        }
        else
        {
            std::cout << "Error: Station could not be found." << std::endl;
        }
    }
    else
    {
        std::cout << "Error: Invalid input." << std::endl;
    }
}

// Short and sweet main.
int main()
{
    print_rasse();

    std::map<std::string, std::vector<std::string>> linesStationsData = {};
    std::set<std::string> stationsRegistry = {};

    std::cout << "Give a name for input file: ";
    std::string inputFileName = "";
    getline(std::cin, inputFileName);

    if(!parseFile(inputFileName, linesStationsData, stationsRegistry))
        return EXIT_FAILURE;

    std::string commandText = "";
    while(true)
    {
        std::cout << "tramway> ";
        getline(std::cin, commandText);
        std::vector<std::string> commandArgs = getCommandArgs(commandText);
        std::string cmd = commandArgs.at(0);
        std::transform(cmd.begin(), cmd.end(), cmd.begin(), ::toupper);
        switch(handleCommand(cmd))
        {
            case Command::QUIT:
                return EXIT_SUCCESS;
            case Command::LINES:
                printLines(linesStationsData);
                break;
            case Command::STATIONS:
                printStations(stationsRegistry);
                break;
            case Command::LINE:
                printLine(linesStationsData, commandArgs.at(1));
                break;
            case Command::STATION:
                printStation(linesStationsData, commandArgs.at(1));
                break;
            case Command::ADD_LINE:
                addLine(linesStationsData, commandArgs.at(1));
                break;
            case Command::ADD_STATION:
                addStation(linesStationsData, stationsRegistry,
                           std::vector<std::string>(commandArgs.begin() + 1, commandArgs.end()));
                break;
            case Command::REMOVE_STATION:
                removeStation(linesStationsData, stationsRegistry, commandArgs.at(1));
                break;
            case Command::UNKNOWN:
                std::cout << "Error: Invalid input." << std::endl;
                break;
        }
    }

    return EXIT_SUCCESS;
}



