#include "loan.hh"
#include <iostream>
using namespace std;
Loan::Loan(Book* book, Person* borrower, Date* today): book_(book),borrower_(borrower),due_date_(today),is_late_(false),renewal_(DEFAULT_RENEWAL_AMOUNT)
{
    due_date_->advance_by_loan_length();
}

Loan::~Loan()
{
    delete due_date_;
    due_date_=nullptr;
}

Book* Loan::get_book()
{
    return book_;
}

Person* Loan::get_borrower()
{
    return borrower_;
}

Date* Loan::get_due_date()
{
    return due_date_;
}

bool Loan::get_is_late()
{
    return is_late_;
}

void Loan::print_information()
{
    cout<<book_->get_title() <<" : "<<
          borrower_->get_name() <<" : "<<
          due_date_->to_string() <<" : "<<
          is_late_ << endl;
}

void Loan::print_loan_taken()
{
   cout<< book_->get_title() <<" : "<<
          due_date_->to_string() <<" : "<<
          is_late_ << endl;
}

bool Loan::renew_loan()
{
    if(renewal_==0)
    {
        return false;
    }
    due_date_->advance_by_loan_length();
    --renewal_;
    return true;
}

void Loan::check_due_date(Date *today)
{
    if(*due_date_<*today)
    {
        is_late_=true;
    }
    else
    {
        is_late_=false;
    }
}











