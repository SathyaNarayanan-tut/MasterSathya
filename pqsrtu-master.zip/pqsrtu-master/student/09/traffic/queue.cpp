#include "queue.hh"
using namespace std;
// Implement the member functions of Queue here



Queue::Queue(unsigned int cycle):cycle_(cycle){

}

Queue::~Queue()
{
    while(first_ != nullptr){
           Vehicle* remove_ptr = first_;
           first_ = remove_ptr->next;
           delete remove_ptr;
    }
}

void Queue::enqueue(string reg)
{
    //    string traffic_colour;
    //    if(is_green_){
    //        traffic_colour = "GREEN";
    //    }
    //    else{
    //        traffic_colour = "RED";
    //    }
        Vehicle* new_vehicle = new Vehicle;
        new_vehicle->reg_num = reg;
        new_vehicle->next = nullptr;
        if(first_==nullptr){
            first_ = new_vehicle;
            last_ = new_vehicle;
        }
        else{
            last_->next = new_vehicle;
            last_ = new_vehicle;
        }

        if(is_green_ && last_ == first_){
            cout << get_light_colour() << ": The vehicle " << new_vehicle->reg_num
                         << " need not stop to wait" << endl;
            first_ = nullptr;
            last_ = nullptr;
            delete new_vehicle;
        }
}

void Queue::switch_light()
{
    if(is_green_){
           is_green_ = false;
       }
       else{
           is_green_ = true;
           if(first_!=nullptr){
               dequeue();
               return;
           }
       }
    if(first_ == nullptr) print();
}

void Queue::reset_cycle(unsigned int cycle)
{
    cycle_ = cycle;
}

void Queue::print()
{
    //    string traffic_colour;
    //    if(is_green_){
    //        traffic_colour = "GREEN";
    //    }
    //    else{
    //        traffic_colour = "RED";
    //    }
        Vehicle* temp_ptr = first_;
        cout << get_light_colour() << ": ";
        if(temp_ptr == nullptr){
            cout << "No vehicles waiting in traffic lights" << endl;
        }
        else{
            cout << "Vehicle(s) ";
            while(temp_ptr != nullptr){
                cout << temp_ptr->reg_num << " ";
                temp_ptr = temp_ptr->next;
            }
            cout << "waiting in traffic lights" << endl;
        }
}
string Queue::get_light_colour(){
    string light_colour;
    if(is_green_){
        light_colour = "GREEN";
    }
    else{
        light_colour = "RED";
    }
    return light_colour;
}

void Queue::dequeue(){
    if(first_ != nullptr){
        Vehicle* move_car = nullptr;
        cout << get_light_colour() << ": "<< "Vehicle(s) ";
        for(unsigned int i=0;i<cycle_;i++){
            if(first_ != nullptr){
                cout << first_->reg_num << " ";
                move_car = first_;
                first_ = first_->next;
                delete move_car;
            }
        }
        cout << "can go on" << endl;
        is_green_ = false;
    }
}
