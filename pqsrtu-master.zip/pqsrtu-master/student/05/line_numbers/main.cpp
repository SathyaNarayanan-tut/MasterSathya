#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main()
{
    std::cout << "Input file: ";
    std::string inputFileName = "";
    getline(std::cin, inputFileName);
    std::ifstream inputFile(inputFileName);

    std::cout << "Output file: ";
    std::string outputFileName = "";
    getline(std::cin, outputFileName);

    if(inputFile)
    {
        std::ofstream outputFile(outputFileName);
        if(outputFile)
        {
            unsigned int lineNumber = 0;
            std::string line;
            while(getline(inputFile, line))
            {
                line = std::to_string(++lineNumber) + " " + line;
                outputFile << line << std::endl;
            }
        }
        else
        {
            std::cout << "Error! The file " << outputFileName << " cannot be opened." << std::endl;
            inputFile.close();
            return EXIT_FAILURE;
        }

        // Close streams
        inputFile.close();
        outputFile.close();
    }
    else
    {
        std::cout << "Error! The file " << inputFileName << " cannot be opened." << std::endl;
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}
